# GridPulse — Edge AI Load Forecasting

GridPulse is an Edge AI prototype for real-time electrical-grid monitoring, lightweight load forecasting, and local anomaly detection.

The original interactive prototype is preserved as the frontend dashboard, while this version adds a Python AI backend and sample dataset so the project has a clearer separation between interface, model, data, and API layers.

## Features

- Interactive distribution-feeder dashboard
- Five simulated substations
- Real-time load simulation
- Holt Linear Trend Exponential Smoothing
- One-step and multi-step forecasting API
- MAPE calculation
- Local anomaly detection
- Edge-versus-cloud latency demonstration
- Sample CSV dataset
- Flask REST API
- CORS support for frontend/backend development

## Project Structure

```text
GridPulse/
├── frontend/
│   └── index.html
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   └── models/
│       ├── __init__.py
│       ├── holt_forecaster.py
│       └── anomaly_detector.py
├── data/
│   └── sample_load.csv
├── README.md
└── .gitignore
```

## AI Approach

The forecasting model uses Holt's Linear Trend Exponential Smoothing. It maintains a smoothed level and trend and predicts future load from these components.

The anomaly detector compares an observed load against the forecast and evaluates the deviation relative to an expected band.

This is intentionally lightweight so the approach is suitable for demonstrating Edge AI concepts on constrained grid-edge devices.

## Run the AI Backend

Create a virtual environment:

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r backend/requirements.txt
```

Start the API:

```bash
python backend/app.py
```

The API runs at:

```text
http://localhost:5000
```

Health check:

```text
http://localhost:5000/api/health
```

## Forecast API

Send:

```json
{
  "substation": "A",
  "steps": 3
}
```

to:

```text
POST /api/forecast
```

Example response:

```json
{
  "substation": "A",
  "latest_actual_kw": 401.24,
  "forecast_kw": [405.12, 408.31, 411.50],
  "mape_percent": 1.42,
  "anomaly": {
    "anomaly": false,
    "deviation_ratio": 0.08,
    "threshold": 1.15
  }
}
```

## Run the Dashboard

The dashboard can be opened directly:

```text
frontend/index.html
```

For the easiest local development setup, use VS Code Live Server or any simple static web server.

## Prototype Note

The browser dashboard contains its own synthetic real-time simulation and can operate without the Python backend. The backend provides a separate, reusable AI/API implementation using the included CSV dataset.

The current prototype is not connected to physical smart meters or real utility infrastructure. Real deployment would require validated grid data, model evaluation, cybersecurity controls, and appropriate electrical-system integration.

## Future Scope

- Real smart-meter and IoT integration
- Real-time streaming data
- Advanced ML/deep-learning forecasting
- Renewable-energy forecasting
- Predictive maintenance
- Fault classification
- Edge-device deployment
- Cloud-edge hybrid architecture
- Model monitoring and retraining

## License

Educational and prototype use.
