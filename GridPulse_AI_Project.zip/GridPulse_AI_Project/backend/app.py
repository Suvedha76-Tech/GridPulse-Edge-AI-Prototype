"""
GridPulse Edge AI API

Run:
    pip install -r requirements.txt
    python app.py

API:
    GET  /api/health
    POST /api/forecast
"""

from pathlib import Path
import csv
from flask import Flask, jsonify, request
from flask_cors import CORS

from models.holt_forecaster import HoltModel, mean_absolute_percentage_error
from models.anomaly_detector import detect_anomaly

app = Flask(__name__)
CORS(app)

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "sample_load.csv"


def load_data():
    rows = []
    with DATA_FILE.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rows.append({
                "timestamp": row["timestamp"],
                "substation": row["substation"],
                "load_kw": float(row["load_kw"]),
            })
    return rows


@app.get("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "project": "GridPulse Edge AI",
        "model": "Holt Linear Trend Exponential Smoothing",
    })


@app.post("/api/forecast")
def forecast():
    payload = request.get_json(silent=True) or {}
    substation = payload.get("substation", "A")
    steps = int(payload.get("steps", 1))

    rows = [r for r in load_data() if r["substation"] == substation]
    if len(rows) < 5:
        return jsonify({"error": "Not enough data for forecasting"}), 400

    values = [r["load_kw"] for r in rows]
    model = HoltModel(alpha=0.35, beta=0.15)
    model.fit(values[:-1])

    prediction = model.predict(steps)
    actual = values[-1]
    previous_forecast = model.predict(1)[0]

    mape = mean_absolute_percentage_error(
        [actual], [previous_forecast]
    )

    band = max(abs(actual) * 0.08, 1.0)
    anomaly = detect_anomaly(actual, previous_forecast, band)

    return jsonify({
        "substation": substation,
        "latest_actual_kw": round(actual, 2),
        "forecast_kw": [round(x, 2) for x in prediction],
        "mape_percent": round(mape, 2),
        "anomaly": anomaly,
        "samples": len(values),
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
