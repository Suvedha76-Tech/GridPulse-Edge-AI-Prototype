"""
GridPulse Edge AI - lightweight forecasting model.

Uses Holt's linear trend exponential smoothing, matching the
forecasting approach demonstrated in the original prototype.
"""

from dataclasses import dataclass
from typing import List


@dataclass
class HoltModel:
    alpha: float = 0.35
    beta: float = 0.15
    level: float = 0.0
    trend: float = 0.0
    fitted: bool = False

    def fit(self, values: List[float]) -> None:
        if not values:
            raise ValueError("values cannot be empty")

        self.level = float(values[0])
        self.trend = 0.0

        for actual in values[1:]:
            previous_level = self.level
            previous_trend = self.trend

            self.level = (
                self.alpha * actual
                + (1 - self.alpha) * (previous_level + previous_trend)
            )
            self.trend = (
                self.beta * (self.level - previous_level)
                + (1 - self.beta) * previous_trend
            )

        self.fitted = True

    def predict(self, steps: int = 1) -> List[float]:
        if not self.fitted:
            raise RuntimeError("Model must be fitted before prediction")

        return [
            self.level + step * self.trend
            for step in range(1, steps + 1)
        ]


def mean_absolute_percentage_error(actual, predicted):
    """Return MAPE as a percentage."""
    if len(actual) != len(predicted):
        raise ValueError("actual and predicted must have equal length")

    errors = []
    for a, p in zip(actual, predicted):
        if a == 0:
            continue
        errors.append(abs(a - p) / abs(a))

    return (sum(errors) / len(errors) * 100) if errors else 0.0
