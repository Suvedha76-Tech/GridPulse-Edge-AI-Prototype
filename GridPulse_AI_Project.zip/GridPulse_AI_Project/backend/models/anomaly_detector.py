"""
GridPulse anomaly detection.
"""

def detect_anomaly(actual: float, forecast: float, expected_band: float,
                   threshold: float = 1.15) -> dict:
    """
    Detect a local load anomaly based on deviation from the forecast.
    """
    deviation = abs(actual - forecast) / max(expected_band, 1e-9)
    return {
        "anomaly": deviation > threshold,
        "deviation_ratio": round(deviation, 3),
        "threshold": threshold,
    }
